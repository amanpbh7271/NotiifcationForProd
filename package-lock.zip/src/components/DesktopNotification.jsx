import React, { useEffect, useState } from 'react';

const DesktopNotification = ({ accountNames }) => {
  const [incidentNumbersP1, setIncidentNumbersP1] = useState({});
  const [incidentNumbersP2, setIncidentNumbersP2] = useState({});
  const [timeForPriorityP1, setTimeForPriorityP1] = useState(15); // Default to 15 minutes
  const [timeForPriorityP2, setTimeForPriorityP2] = useState(30); // Default to 30 minutes
 
  useEffect(() => {
    // Function to fetch time for priority P1 and P2
    const fetchTimeForPriorities = async () => {
      try {
        const response = await fetch(`http://localhost:8080/api/timeForPriority`);
        if (response.ok) {
          const data = await response.json();
          setTimeForPriorityP1(parseInt(data.P1)); // Convert time to integer for P1
          setTimeForPriorityP2(parseInt(data.P2)); // Convert time to integer for P2
        } else {
          console.error('Failed to fetch time for priorities P1 and P2:', response.statusText);
        }
      } catch (error) {
        console.error('Error occurred while fetching time for priorities P1 and P2:', error);
      }
    };

    // Function to fetch incident numbers for the specified account and priority
    const fetchIncidentNumbers = async (priority, accountName) => {
      try {
        const response = await fetch(`http://localhost:8080/api/listOfIncFromAccountAndPriority/${priority}/${accountName}`);
        if (response.ok) {
          const data = await response.json();
          if (priority === 'P1') {
            setIncidentNumbersP1(prevState => ({ ...prevState, [accountName]: data }));
          } else if (priority === 'P2') {
            setIncidentNumbersP2(prevState => ({ ...prevState, [accountName]: data }));
          }
        } else {
          console.error(`Failed to fetch incident numbers for priority ${priority}:`, response.statusText);
        }
      } catch (error) {
        console.error(`Error occurred while fetching incident numbers for priority ${priority}:`, error);
      }
    };

    // Fetch time for priorities P1 and P2 initially
    fetchTimeForPriorities();

    // Fetch incident numbers initially for each account
    if (accountNames) {
      accountNames.forEach(accountName => {
        fetchIncidentNumbers('P1', accountName);
        fetchIncidentNumbers('P2', accountName);
      });
    }

    // Schedule fetching incident numbers every timeForPriorityP1 minutes for P1
    const intervalIdP1 = setInterval(() => {
      if (accountNames) {
        accountNames.forEach(accountName => fetchIncidentNumbers('P1', accountName));
      }
    }, timeForPriorityP1 * 60 * 1000);

    // Schedule fetching incident numbers every timeForPriorityP2 minutes for P2
    const intervalIdP2 = setInterval(() => {
      if (accountNames) {
        accountNames.forEach(accountName => fetchIncidentNumbers('P2', accountName));
      }
    }, timeForPriorityP2 * 60 * 1000);

    // Clean up intervals on component unmount
    return () => {
      clearInterval(intervalIdP1);
      clearInterval(intervalIdP2);
    };
  }, [accountNames, timeForPriorityP1, timeForPriorityP2]);

  useEffect(() => {
    // Function to show desktop notification with incident numbers
    const showNotification = (priority, incidentNumbers, accountName) => {
      // Check if the browser supports notifications
      if (!("Notification" in window)) {
        console.error("This browser does not support desktop notification");
        return;
      }

      // Check if permission is granted
      if (Notification.permission === "granted") {
        // Construct notification message with incident numbers
        const notificationMessage = incidentNumbers ? incidentNumbers.join('\n') : '';

        // Show notification with incident numbers
        new Notification(`Open ${priority} Incidents for Account: ${accountName}`, { body: notificationMessage });
      } else if (Notification.permission !== "denied") {
        // Request permission
        Notification.requestPermission().then(permission => {
          if (permission === "granted") {
            // Show notification with incident numbers
            showNotification(priority, incidentNumbers, accountName);
          }
        });
      }
    };

    // Show notifications for each account and priority
    if (accountNames) {
      accountNames.forEach(accountName => {
        if (incidentNumbersP1[accountName]?.length > 0) {
          showNotification('P1', incidentNumbersP1[accountName], accountName);
        }
        if (incidentNumbersP2[accountName]?.length > 0) {
          showNotification('P2', incidentNumbersP2[accountName], accountName);
        }
      });
    }
  }, [incidentNumbersP1, incidentNumbersP2, accountNames]);

  return null; // This component doesn't render anything
};

export default DesktopNotification;
